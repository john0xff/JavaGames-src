/*
 * Main Snake Game Application Launcher
 */
package snakeapplication;

public class Main
{
    static SnakeApplication game;

    Main()
    {
        game = new SnakeApplication();
    }

    public static void main(String[] args) 
    {
        new Main();
    }
}
